
window.automate_core_url = 'ws://127.0.0.1:4000';
